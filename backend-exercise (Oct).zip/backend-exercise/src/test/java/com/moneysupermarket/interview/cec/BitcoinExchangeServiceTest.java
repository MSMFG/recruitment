package com.moneysupermarket.interview.cec;

import org.junit.Test;

public class BitcoinExchangeServiceTest {

    @Test
    public void testTemp(){
        // example
    }
}

